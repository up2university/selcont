<?php

/**
 * Provide a dashboard view for the plugin
 *
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
