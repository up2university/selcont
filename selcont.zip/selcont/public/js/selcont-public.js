(function( $ ) {
	'use strict';

    $( '#selcont-tl' ).click(function() {
        $( '#selcont-slide' ).addClass( 'selcont-slide-active' );
    });
	

})( jQuery );
